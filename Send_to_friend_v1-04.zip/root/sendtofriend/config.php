<?php
// Send to a Friend V1.04


$path_to_script = "http://www.yoursite.com/folder_with_sendtofriend";//The path on your server where the script lives
$title        = 'Liquid Frog Free Send to a Friend script';        // The title of the main page
$title_font_face        = 'verdana';        // The font of the title
$title_font_size        = 2;        // The size of the title on the main page
$title_font_style        = 'x';        // The style of the title font - values are i - italics, u - underline etc  or x to turn off
$title_font_weight        = 'b';        // The weight of the title font - values are bold/normal
$title_font_color        = 'red';        // The color of the title on the main page use color e.g. red or values e.g. #FFFFFF
$title_alignment        = 'center';        // The position of the title - values left/center/right
$form_align        = 'center';        // The alignment of the send to a friend form fields
$font_face        = 'verdana';        // The font face of the send to a friend form fields
$font_size        = 1;        // The font size of the send to a friend form fields
$font_color        = 'blue';        // The font color of the send to a friend form fields
$default_url        = 'http://www.yoursite.com/';        // The url to send to the friend
$footer_text        = 'You can add your own text in here if you want';        // The text you want in the page footer (leave blank for none)
$footer_font_face        = 'verdana';        // The font of the footer text
$footer_font_size        = 10;        // The font size of the footer text on the main page
$footer_font_style        = 'i';        // The style of the footer text font- values are i - italics, u - underline etc or x to turn off
$footer_font_weight        = 'b';        // The weight of the footer text font - values are bold/normal
$footer_font_color        = 'green';        // The color of the footer text on the main page
$footer_alignment        = 'center';        // The position of the footer - values left/center/right
$abuse_message        = 'To prevent abuse, your IP address has been recorded as - ';        // The message to show next to users IP address
$own_mail_address_error        = 'Your own e-mail address is invalid. Please check it.';        // The error message to show when a senders email address in wrong
$no_senders_name        = 'You forgot to fill in your name. Please enter it into the form.';        // The error message to show when no senders name has been entered
$no_friends_name        = 'You forgot to fill in your friends name. Please enter it into the form.';        // The error message to show when no friends name has been entered
$friends_mail_address_error        = 'The e-mail address you entered for your friend does not seem to be valid. Please check it.';        // The error message to show when a friends email address is wrong
$cant_send_mail        = 'There was a problem that prevented the information being sent. Please use your back button or press shift/refresh to refresh the page and try again.';        // The error message to show if an unexpected problem ocurrs
$mail_sent_message        = 'has been sent the information and any message you added.';        // The message to show once mail has been sent
$success_url        = 'http://www.yoursite.com/anywhere_you_like.htm';        // Where to send your visitor if the mail is sent
$email_sent_message_title        = 'Your mail was sent';        // The page title to show your visitor once the mail has been sent
$email_sent_message_font        = 'verdana';        // The font of the page title to show your visitor once the mail has been sent
$email_sent_message_title_alignment        = 'center';        // The aligment of the email sent message
$email_sent_message_size        = 14;        // The font size for email sent message title
$recommend_this_site_message        = 'Send this site to a friend by completing the form below and clicking Send.';        // The message to show visitors below the main page title
$align_message        = 'center';        // The alignment of the recommend this site message

?>
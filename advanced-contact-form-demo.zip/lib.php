<?php
$host = "Localhost";
$username = "USERNAME";
$password = "PASSWORD";
$db = "DATABASE";

// DO NOT EDIT BELOW
$table ="advanced";

?>

<?
//Sending auto respond Email to user
$pfw_header = "From: your@email-address.com";
?>
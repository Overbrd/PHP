<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Advanced Contact Form</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#9595FF">
<div align="center">
  <table width="550" cellspacing="0" cellpadding="0">
    <tr>
      <td bgcolor="#FFFFFF"> <div align="center">
          <p><img src="header.jpg" width="550" height="136"><br>
          </p>
          <p><font color="#0000FF" size="6" face="Arial, Helvetica, sans-serif"><strong>THANK 
            YOU!</strong></font></p>
          <p><strong><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">Your 
            information has been sent.</font></strong></p>
          <p><font color="#000000" size="4"><strong><font face="Arial, Helvetica, sans-serif">Please 
            Allow 24hrs for a response.</font></strong></font></p>
          <p>&nbsp;</p>
        </div></td>
    </tr>
  </table>
  
</div>
</body>
</html>

<?php
include("lib.php");
$link = mysql_connect($host,$username,$password);
if (!$link) {
die('Could not connect: ' . mysql_error());
}
$db_selected = mysql_select_db($db, $link);
if (!$db_selected) {
die ("Can't use $db : " . mysql_error());
}
$sql = "CREATE TABLE IF NOT EXISTS`advanced` (`id` INT (7) NOT NULL auto_increment ,`First_Name` VARCHAR (20) DEFAULT '20',`Last_Name` VARCHAR (20) DEFAULT '20',`Address` VARCHAR (20) DEFAULT '20',`City` VARCHAR (20) DEFAULT '20',`State` VARCHAR (20) DEFAULT '20',`Zip` VARCHAR (20) DEFAULT '20',`Home_Phone` VARCHAR (20) DEFAULT '20',`Cell_Phone` VARCHAR (20) DEFAULT '20',`Notes` VARCHAR (200) DEFAULT '200',`Business_Phone` VARCHAR (20) DEFAULT '20',`Fax_Number` VARCHAR (20) DEFAULT '20',`eMail_Address` VARCHAR (50) DEFAULT '50',`Website_Address` VARCHAR (50) DEFAULT '50',PRIMARY KEY(`id`))";
$result = mysql_query($sql);
if (!$result) {
die('Invalid query: ' . mysql_error());
}echo "Table created successfully";

?>

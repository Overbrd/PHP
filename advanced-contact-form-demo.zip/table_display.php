<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>
<title>table display</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="table.css" type="text/css">
</head>
<body style="margin: 0 0 0 0;">
<?

@$start = $_GET["start"];
if($start =='')
    $start =0;
include("lib.php");
$link = mysql_connect($host,$username,$password);
if (!$link) {
    die('Could not connect: ' . mysql_error());
}
$db_selected = mysql_select_db($db, $link);
if (!$db_selected) {
    die ("Can't use $db : " . mysql_error());
}
//total number of records in the table
$res = mysql_query("SELECT * from `$table`");
@$rows = mysql_num_rows ($res);

$result = mysql_query("SELECT * from `$table` limit $start,10");
if (!$result) {
    die('Invalid query: ' . mysql_error());
}
 echo "<p align=center class = 'menu'> Table : $table </p>";
$cols = mysql_num_fields($result);
$records = mysql_num_rows ($result);
 echo "<table align='center' width='700' >";
 echo "<tr bgcolor='BBCCDD' class='menu'>";
 for ($i = 0; $i < $cols;$i++)
 {
    echo "<td align='center'>".mysql_field_name($result,$i)."</td>";
 }
 echo "</tr>";
 while ($row = mysql_fetch_array($result, MYSQL_NUM))
 {
    echo "<tr bgcolor='F6F6F6' class='normal'>";

   foreach ($row as $value)
   { echo "<td align='center'>".$value ."</td>";
   } 


   echo "</tr>";
 }
 $end = $start + $records;
 echo "<tr  align = 'center' bgcolor = 'BBCCDD' class='menu'><td colspan=$cols> Records $start  to  $end  of $rows </td></tr>";
 echo "<tr  align = 'center' class='mylink'><td colspan=$cols> ";


     if($start<$rows-10)
     {
       $next = $start + 10;
       echo "<a href = 'table_display.php?start=$next'>Next</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
    }
    if($start != 0)
    {
    $prev = $start - 10;
    echo "<a  href='table_display.php?start=$prev'> previous </a> ";
    }
     echo "</td></tr>";
     echo "</table>";
 ?>
</body>

</html>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Advanced Contact Form</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#9595FF">
<div align="center">
  <table width="550" cellspacing="0" cellpadding="0">
    <tr>
      <td bgcolor="#FFFFFF"> <div align="center">
          <p><img src="header.jpg" width="550" height="136"><br>
          </p>
          <p><font color="#FF0000" size="6" face="Arial, Helvetica, sans-serif"><strong>ERROR</strong></font></p>
          <p><strong><font size="3" face="Arial, Helvetica, sans-serif">Please 
            go back and check your input.</font></strong></p>
          <p><a href="javascript: history.go(-1)"><font size="4" face="Arial, Helvetica, sans-serif">Previous 
            Page</font></a> </p>
          <p>&nbsp;</p>
        </div></td>
    </tr>
  </table>
  
</div>
</body>
</html>

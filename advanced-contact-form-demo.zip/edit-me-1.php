<?
@$pfw_host = "Localhost";
@$pfw_user = "USER-NAME";
@$pfw_pw = "PASSWORD";
@$pfw_db = "DATABASE-NAME";
// Use Lower Case!
?>